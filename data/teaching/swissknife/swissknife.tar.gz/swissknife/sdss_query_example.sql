SELECT TOP 5000
  s.ra, s.dec,
   
  s.z, s.zErr,
  s.velDisp, s.velDispErr,
  s.snMedian,
  
  l.Sigma_Ha_6562 as sigHa, l.Sigma_Ha_6562_Err as sigHaErr,
  l.Sigma_Hb_4861 as sigHb, l.Sigma_Hb_4861_Err as sigHbErr,
  
  mpa.lgm_tot_p50 as lgm, (mpa.lgm_tot_p84-mpa.lgm_tot_p16)/2. as lgm_Err,
  mpa.sfr_tot_p50 as lsfr, (mpa.sfr_tot_p84-mpa.sfr_tot_p16)/2. as lsfr_Err
  
INTO mydb.methclass
FROM SpecObj AS s
  JOIN emissionLinesPort as l ON s.specobjid=l.specobjid
  JOIN galSpecExtra as mpa on s.specobjid=mpa.specobjid
  
WHERE mpa.lgm_tot_p50 > 9 AND s.velDispErr > 0 AND l.Sigma_Ha_6562_err > 0
