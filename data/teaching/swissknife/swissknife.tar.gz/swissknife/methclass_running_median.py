# created by francesco.deugenio@ugent.be 25 May 2019

import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import binned_statistic

import methclass_common as mc


def running_median(bins=np.arange(1.4, 3.5, 0.15)):

    m, ss, sg, um, uss, usg = mc.load_data()

    runmed, _, _ = binned_statistic(ss, sg, bins=bins, statistic=np.median)


    plt.errorbar(ss, sg, xerr=uss, yerr=usg, marker='o', color='b', alpha=0.3,
                 capthick=2, lw=2, capsize=5, linestyle='')                                                                         
    bin_centres = (bins[1:]+bins[:-1])/2.
    plt.plot(bin_centres, runmed, 'kD', zorder=5, ms=15)
   
    plt.xlabel('$\log \, \sigma_\star \; [\mathrm{km \; s^{-1}}]$', fontsize=45)                   
    plt.ylabel('$\log \, \sigma_\mathrm{H\\alpha} \; [\mathrm{km \; s^{-1}}]$', fontsize=45)       
    plt.title('$\mathrm{A \; running \; median}$', fontsize=45)                                    

    ax = plt.gca()                                                                                 
    ax.set_aspect('equal')                                                                         

    plt.xlim(1.41, 3.2); plt.ylim(1.41, 3.2)     
    plt.show()


if __name__ == "__main__":
    running_median()
