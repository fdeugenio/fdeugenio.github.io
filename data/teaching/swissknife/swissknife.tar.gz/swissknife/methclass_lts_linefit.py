# created by francesco.deugenio@ugent.be 25 May 2019

import matplotlib.pyplot as plt
import numpy as np

try:
    from ltsfit.lts_linefit import lts_linefit
except (ImportError, IOError, Exception) as e:
    print("\nTry to install ltsfit, e.g. pip3 install ltsfit\n")
    raise e

import methclass_common as mc


def lts_example_fit():

    m, ss, sg, um, uss, usg = mc.load_data()

    pivot = 2 # This is roughly equal to the mean of `ss`.
    ltssg = lts_linefit(ss, sg, uss, usg, pivot=pivot, plot=False)

    plt.figure(figsize=(16,10))                                                                    
    ax = plt.gca()                                                                                 
    ax.set_aspect('equal')                                                                         
   
    mask = ltssg.mask                                                                              

    plt.errorbar(ss[mask], sg[mask], xerr=uss[mask], yerr=usg[mask], marker='o', color='b', alpha=0.3, capthick=2, lw=2, capsize=5, linestyle='')                                         
    plt.errorbar(ss[~mask], sg[~mask], xerr=uss[~mask], yerr=usg[~mask], marker='d', color='g', alpha=0.3, capthick=2, lw=2, capsize=5, linestyle='')            

    b, a = ltssg.ab                                                                                
   
    xxx = np.arange(1.41, 3.2, .01)                                                                
    plt.plot(xxx, a * (xxx - pivot) + b, 'r--', lw=3, zorder=5)                                    

    plt.xlabel('$\log \, \sigma_\star \; [\mathrm{km \; s^{-1}}]$', fontsize=45)                   
    plt.ylabel('$\log \, \sigma_\mathrm{H\\alpha} \; [\mathrm{km \; s^{-1}}]$', fontsize=45)       
    plt.title('$\mathrm{LTS \; linefit}$', fontsize=45)                                    

    plt.xlim(1.41, 3.2); plt.ylim(1.41, 3.2)     
    plt.show()


if __name__ == "__main__":
    lts_example_fit()
