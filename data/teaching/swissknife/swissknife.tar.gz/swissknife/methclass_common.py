# created by francesco.deugenio@ugent.be 25 May 2019

import numpy as np
import matplotlib.pyplot as plt

from astropy import table


def load_data(filename='methclass_fdeugenio.fit'):

    tab = table.Table.read('methclass_fdeugenio.fit')                                              

    m, ss, sg, um, uss, usg = [
        tab[key] for key in
        ['lgm', 'velDisp', 'sigHa', 'lgm_Err', 'velDispErr', 'sigHaErr']]

    m, ss, sg, um, uss, usg = (
        m, np.log10(ss), np.log10(sg), um,
        np.log10(np.e) * uss/ss, np.log10(np.e) * usg/sg)

    v = (uss < 0.1) & (usg < 0.1) & (sg > np.log10(35.)) & (m>9) & (usg>0) & (uss>0)               

    m, ss, sg, um, uss, usg = [_x_[v] for _x_ in [m, ss, sg, um, uss, usg]]         

    return m, ss, sg, um, uss, usg
