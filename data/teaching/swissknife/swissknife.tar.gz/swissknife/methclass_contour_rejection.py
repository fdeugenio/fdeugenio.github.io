from scipy.ndimage.filters import gaussian_filter 
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import path 

import methclass_common as mc


def contour_rejection_example(percentile=95):

    m, ss, sg, um, uss, usg = mc.load_data()

    inside = contour_rejection(ss, sg, percentile=percentile, plot=1)
    ax = plt.gca()                                                                                 
    ax.set_aspect('equal')                                                                         
   
    plt.xlabel('$\log \, \sigma_\star \; [\mathrm{km \; s^{-1}}]$', fontsize=45)                   
    plt.ylabel('$\log \, \sigma_\mathrm{H\\alpha} \; [\mathrm{km \; s^{-1}}]$', fontsize=45)       
    plt.title('$\mathrm{Contour \; rejection}$', fontsize=45)                                    

    plt.xlim(1.41, 3.2); plt.ylim(1.41, 3.2)     
    plt.show()



def contour_rejection(x, y, percentile=90, bins=(25, 25), plot=False):
    h, bx, by = np.histogram2d(x, y, bins=bins) 
    bxc, byc = (bx[1:]+bx[:-1])/2., (by[1:]+by[:-1])/2. 
    h = gaussian_filter(h.T, 2) 

    # Normalise the histogram. 
    hn = h/h.sum() 

    # Sort the histogram. 
    hs = hn.flatten() 

    # Get the bin ids. 
    asort = np.argsort(hs) 
    level = 1. - percentile/100. 
    idx = np.where(hs[asort].cumsum()>=level) 

    hf = np.zeros_like(hs) 
    hf[asort[idx]] = 1 

    hf = hf.reshape(len(bxc), len(byc)) 

    bxc_fix = np.hstack([bxc[0] - 1., bxc, bxc[-1] + 1.]) 
    byc_fix = np.hstack([byc[0] - 1., byc, byc[-1] + 1.]) 
    hf_fix = np.zeros((len(bxc_fix), len(byc_fix))) 
    hf_fix[1:-1, 1:-1] = hf 

    # Retrieve the contours. 
    alpha = 1.0 if plot else 0.0 
    cs = plt.contour(bxc_fix, byc_fix, hf_fix, [0.5], alpha=alpha, 
                     linewidths=2, colors='k') 

    vertices = cs.collections[0].get_paths()[0].vertices 
    polygon = path.Path(vertices) 

    inside = polygon.contains_points(np.array([x, y]).T) 

    if plot: 
        plt.close()
        plt.figure(figsize=(16,10))
        plt.imshow(hf, extent=(bxc[0], bxc[-1], byc[0], byc[-1]), origin='lower') 
        plt.plot(x[inside], y[inside], 'g.', alpha=0.5) 
        plt.plot(x[~inside], y[~inside], 'r.', alpha=0.5) 

    return inside 



if __name__ == "__main__":
    contour_rejection_example()
# created by francesco.deugenio@ugent.be 25 May 2019
